package hotel.management.system;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class HotelManagementSystem extends JFrame implements ActionListener {

    HotelManagementSystem() {
        setSize(1024, 683);
        
        setTitle("HOTEL MANAGEMENT SYSTEM"); // Set the title
        setVisible(true);
        ImageIcon il = new ImageIcon(ClassLoader.getSystemResource("icons/first.jpg"));
        JLabel image = new JLabel(il);
        add(image);

        // Add a label for the name at the center
        JLabel nameLabel = new JLabel("क्षणभर विश्रांती ");
        nameLabel.setBounds(0, 50, 1024, 100); // Adjust the position and size as needed
        nameLabel.setForeground(Color.GREEN);
        nameLabel.setFont(new Font("serif", Font.BOLD, 48));
        nameLabel.setHorizontalAlignment(SwingConstants.CENTER); // Center align the text
        image.add(nameLabel);

        JButton next = new JButton("NEXT");
        next.setBounds(850, 550, 150, 50);
        next.setBackground(Color.WHITE);
        next.setForeground(Color.RED);
        next.addActionListener(this);
        next.setFont(new Font("serif", Font.PLAIN, 24));
        image.add(next);

        setVisible(true);
    }

    public void actionPerformed(ActionEvent ae) {
        setVisible(false);
        new Login();
    }

    public static void main(String[] args) {
        new HotelManagementSystem();
    }
}
